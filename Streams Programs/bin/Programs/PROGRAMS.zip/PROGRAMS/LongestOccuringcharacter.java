import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class LongestOccuringcharacter {

	public  static void main(String args[]) {
		
		String str = "aabbbbbcc";
		
		List<String> lst = Arrays.asList(str.split(""));
		Map.Entry<String,Long> max = lst.stream()
        .collect(Collectors.groupingBy(String::valueOf, Collectors.counting()))
        .entrySet()
        .stream().max(Map.Entry.comparingByValue())
        .get();
		
		System.out.println(max);
		
	}
}
