import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class SecondLargestOrSmallest {
	public static void main(String args[]) {
		List<Integer> nums = Arrays.asList(1, 17, 54, 14, 14, 33, 45, -11);
		
		//secondSmallest
		int secondSmallest = nums.stream().sorted().distinct().skip(1).findFirst().get();
		System.out.println(secondSmallest);
		
		//secondHighest
		int secondHighest = nums.stream().sorted(Collections.reverseOrder()).distinct().skip(1).findFirst().get();
		System.out.println(secondHighest);
	}
}
