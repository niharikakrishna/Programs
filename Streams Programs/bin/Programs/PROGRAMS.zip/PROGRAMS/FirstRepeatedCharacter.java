import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class FirstRepeatedCharacter {
	/**
	 * @param args
	 */
	public static void main(String args[]) {
		
		String str = "developer";
		
		List<String> items = Arrays.asList(str.split(""));
		
		System.out.println("Actual String: " + items);
		
		Set<String> dup = items.stream().filter(e -> Collections.frequency(items,e)>1).collect(Collectors.toSet());
		System.out.println("set items: "+ dup);
		System.out.println("First repeated character: " + dup.iterator().next());
	}
}
